public class Main {

	/**
	 * This is the entry point for the very simple hello world app. 
	 */	
	public static void main(String[] args) {
		System.out.println("Hello from Simple Java application!");
	}

}
